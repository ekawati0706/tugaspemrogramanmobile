package com.example.myapplication2

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.row.view.*


class MainActivity : AppCompatActivity() {
    var listBahasa=ArrayList<bahasa>()
    var adapter:AdapterBahasa?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listBahasa.add(
            bahasa("Ruby","bahasa pemrograman dinamis berbasis skrip yang berorientasi objek",R.drawable.ruby))
        listBahasa.add(
            bahasa("python","bahasa pemrograman interpretatif multiguna dengan filosofi perancangan yang berfokus pada tingkat keterbacaan kode.",R.drawable.python))
        listBahasa.add(
            bahasa("Ralls","sebuah kerangka kerja aplikasi web sumber terbuka yang berjalan via bahasa pemrograman Ruby.",R.drawable.ralls))
        listBahasa.add(
            bahasa("JavaScript","ahasa pemrograman tingkat tinggi dan dinamis.",R.drawable.java))
        listBahasa.add(
            bahasa("PHP","bahasa skrip yang dapat ditanamkan atau disisipkan ke dalam HTML.",R.drawable.php))

        adapter=AdapterBahasa(listBahasa,this)
        listView.adapter=adapter

    }
    inner class AdapterBahasa: BaseAdapter {
        var listBahasa= ArrayList<bahasa>()
        var contex: Context?=null

        constructor(listBahasa: ArrayList<bahasa>, contex: Context?) : super() {
            this.listBahasa = listBahasa
            this.contex = contex
        }

        override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
            val bahasa =listBahasa[p0]
            val inflator= contex!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE)as LayoutInflater
            var myView =
                inflator.inflate(R.layout.row,null)
            myView.nama.text=bahasa.nama!!
            myView.title.text=bahasa.deskripsi!!
            myView.image.setImageResource(bahasa.gambar!!)
            return myView


        }

        override fun getItem(p0: Int): Any {
            return listBahasa[p0]

        }

        override fun getItemId(p0: Int): Long {
            return p0.toLong()
        }

        override fun getCount(): Int {
            return listBahasa.size
        }

    }
}



